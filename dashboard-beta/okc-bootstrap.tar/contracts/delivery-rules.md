# Rules for work in this workspace

These govern how work is delivered, not what the work is.

* Commit everything you change. Work that is not committed does not exist.
* Push to `origin` on the branch you were set up on, and do not switch branches.
* Write commit messages that say what changed and why, not what you did today.
* Do not touch any repository you were not asked about.

## Never write a bare `#42` in a commit message

Name an issue in full — `trustcrypto/onlykey-agent#42` — or say "issue 42 in
onlykey-agent" in words. Never `#42` on its own.

**These repositories are forks, and GitHub resolves a bare number against the
fork's NETWORK rather than the repository your commit is in.** Two commits on
the first real change done here said `(issue #42)`, meaning
`trustcrypto/onlykey-agent#42`. They were pushed to `bm-ok/0c-coder-lib-agent`,
a fork whose network source is `romanz/trezor-agent` — so GitHub rendered both
as links to `romanz/trezor-agent#42`, a pull request in a stranger's repository
about something else. The person who asked for the work found it on the pull
request and asked why it cited the wrong thing.

A commit message cannot be corrected once it is pushed and read. It is the one
thing you write here that is permanent, so it is worth the extra dozen
characters every time — including when the repository you are in is obviously
the one you meant, because on GitHub it is not.