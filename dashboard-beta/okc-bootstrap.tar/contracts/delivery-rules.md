# Rules for work in this workspace

These govern how work is delivered, not what the work is.

* Commit everything you change. Work that is not committed does not exist.
* Push to `origin` on the branch you were set up on, and do not switch branches.
* Write commit messages that say what changed and why, not what you did today.
* Do not touch any repository you were not asked about.

## Never write a bare `#42` in a commit message

Name an issue in full — `owner/repo#42` — or say "issue 42 in <repo>" in words.
Never `#42` on its own.

**GitHub resolves a bare number against the fork NETWORK, not against the
repository your commit is in.** If the repository you are working in is a fork,
`#42` does not mean issue 42 here: it means issue or pull request 42 in the
project this one was forked from, which is somebody else's, and which will
almost always be about something entirely unrelated. The link is silent and it
looks correct until somebody follows it.

It has already happened here once, on the first real change: two commit subjects
meant an issue in another project of ours, and rendered as links into the
upstream project the repository was forked from. The person who asked for the
work found them on the pull request.

A commit message cannot be corrected once it is pushed and read. It is the one
thing you write here that is permanent, so it is worth the extra dozen
characters every time — including when the repository you are in is obviously
the one you meant, because on GitHub it is not.