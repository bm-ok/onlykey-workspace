#!/bin/bash
# This project's extra setup — the USER half.
#
# Runs as the user, after the app's user toolchain, so node through nvm is already
# there and this can rely on it.
#
# Anything system-wide is in extra.sh, which runs as root before this. If something
# here needs a package or a udev rule, that is where it belongs.
#
# A header of OKC_* values and `say`/`report` helpers is prepended by the dashboard.
# $HOME and $USER are the user's own here.

set -u

say "extra (user): starting as $(id -un)"

# --- where work happens -------------------------------------------------------
#
# One folder, in the user's home, made by the user. Nothing is cloned into it here:
# what belongs in it is this project's business and changes more often than a
# provisioning script should.

mkdir -p "$HOME/work"
say "work goes in $HOME/work"

# --- the worker that actually does the work -----------------------------------
#
# Claude Code, installed for the user rather than system-wide, because node here
# comes from nvm and a global install under nvm IS the user's.
#
# No credential is installed with it, deliberately -- a key baked in here would
# end up in every snapshot of every machine ever built from this point. A
# credential arrives later, if at all, by vmCredentialsPut, and is taken away
# again by vmCredentialsForget.
#
# It does land on the machine's disk when it arrives, and that is not something
# this script can change: Claude Code reads the file itself, as this user. What
# is done about it is on the host side -- the dashboard records which machines
# are holding one and REFUSES to snapshot those, because a snapshot would keep a
# copy for as long as the snapshot exists, and it redacts anything credential-
# shaped out of transcripts and run logs on the way back, because those are kept.
#
# In the PROJECT's script rather than the app's: the dashboard does not know what
# a machine is for, and a machine that runs an agent is a choice this project
# makes.

say 'installing the worker'
if bash -lc 'command -v claude >/dev/null 2>&1'; then
  say "claude is already here: $(bash -lc 'claude --version 2>/dev/null' | head -1)"
else
  # A login shell, so nvm's node and its global prefix are the ones used. Without
  # it npm is either missing or the distribution's, and a global install lands
  # somewhere root owns and the user cannot run.
  if bash -lc 'npm install -g @anthropic-ai/claude-code >/dev/null 2>&1'; then
    say "claude installed: $(bash -lc 'claude --version 2>/dev/null' | head -1)"
  else
    say 'WARNING: could not install claude -- this machine cannot be given work until it is'
  fi
fi

# --- the supervisor the emulator runs under -----------------------------------
#
# pm2, installed for the user for the same reason claude is: node here comes from
# nvm, so a global install IS the user's and needs no root.
#
# It belongs in provisioning rather than in the project's setup.sh because it is a
# TOOL, not a dependency. No package.json in the workspace asks for it, so no
# install can bring it in -- yet every npm script in the emulator repo shells out
# to it and the README's Running section opens with it. setup.sh does install it
# when it is absent, and that works, but it means a global npm install sitting in
# a script whose job is meant to end at the workspace.

say 'installing the supervisor'
if bash -lc 'command -v pm2 >/dev/null 2>&1'; then
  say "pm2 is already here: $(bash -lc 'pm2 --version 2>/dev/null' | head -1)"
elif bash -lc 'npm install -g pm2 >/dev/null 2>&1'; then
  say "pm2 installed: $(bash -lc 'pm2 --version 2>/dev/null' | head -1)"
else
  say 'WARNING: could not install pm2 -- the emulator cannot be started until it is'
fi

# --- the python dependencies, built before the venv exists --------------------
#
# setup.sh creates okpqc-venv beside the checkouts and pip-installs the two
# component trees into it. WHERE that venv goes is not knowable from here -- it
# depends where the repos get cloned -- so the venv cannot be made in advance.
#
# Its contents can. pip keeps two caches under ~/.cache/pip: the archives it
# downloads, and the wheels it builds from source distributions. Both are
# per-user, both are independent of where any venv lives, and pip consults both
# with no flag and no configuration. So installing the dependency set into a
# throwaway venv here means the real one later resolves every package from local
# disk, and -- for the ones that ship no wheel -- unpacks a wheel that has already
# been compiled instead of compiling it again.
#
# THE COMPILES ARE THE POINT. hidapi, pynacl, pycryptodome and Cython all build C
# extensions, minutes apiece on a small VM, and they are why a first setup.sh sits
# there looking like it has hung. python3-dev, pkg-config, libudev-dev and
# libusb-1.0-0-dev come from extra.sh precisely so those builds succeed HERE,
# where the time is already being spent, rather than fail into an empty cache.
#
# The list is the union of python-onlykey's install_requires and its [age] extra
# with lib-agent's. Deliberately only the THIRD-PARTY leaves: `onlykey` and
# `lib-agent` are installed by setup.sh as editable checkouts, and fetching the
# PyPI copies here would cache a release that nothing ends up using.
#
# The throwaway venv is thrown away. Only the cache is wanted, and a venv left
# lying in a home directory is one more thing to wonder about later.
#
# Nothing here can break setup.sh: it resolves against the real setup.py files
# whatever is in the cache. A stale entry costs one cached package nobody
# installs; a missing one costs the time it would have cost anyway.

say 'pre-building the python dependencies into the pip cache'

OKC_PY_DEPS=(
  hidapi aenum six 'prompt_toolkit>=2' 'pynacl>=1.4.0' 'ecdsa>=0.13'
  'Cython>=0.23.4' 'onlykey-solo-python>=0.0.31'
  'cryptography>=41.0' 'kyber-py>=1.0'
  'bech32>=1.2.0' 'pycryptodome>=3.9.8' 'docutils>=0.16' 'python-daemon>=2.3.0'
  'ConfigArgParse>=0.12.1' 'mnemonic>=0.18' 'pymsgbox>=1.0.6' 'semver>=2.2'
  'unidecode>=0.4.20'
)

# Under $HOME rather than /tmp: this unpacks a few hundred megabytes, and a small
# VM's /tmp is often a tmpfs sized off RAM.
OKC_WARM="$HOME/.cache/okc-warm"
rm -rf "$OKC_WARM"
mkdir -p "$OKC_WARM"

if python3 -m venv "$OKC_WARM/venv" >/dev/null 2>&1; then
  "$OKC_WARM/venv/bin/pip" install --upgrade pip >/dev/null 2>&1 || true
  if "$OKC_WARM/venv/bin/pip" install "${OKC_PY_DEPS[@]}" >/dev/null 2>&1; then
    say 'python dependencies are cached — okpqc-venv will resolve them from disk'
  else
    # Partial is still worth having: everything fetched before the failure is in
    # the cache, and setup.sh builds the remainder exactly as it would have.
    say 'WARNING: some python dependencies did not pre-build — setup.sh will build those'
  fi
else
  say 'WARNING: python3 -m venv failed — is python3-venv installed? (extra.sh installs it)'
fi
rm -rf "$OKC_WARM/venv"

# --- the node dependencies, fetched before the checkouts exist ----------------
#
# setup.sh runs npm install in five places: the emulator addon, the GUI, the test
# kit, the OnlyKey App and the web app. npm's cache is ~/.npm/_cacache --
# content-addressed, per-user, consulted automatically, and again independent of
# where any of those checkouts end up. Installing the direct dependencies into a
# throwaway directory here pulls the WHOLE TRANSITIVE CLOSURE into that cache, not
# just the names listed below, so the real installs later are resolution and
# unpacking rather than several hundred HTTP requests.
#
# --ignore-scripts, and it is worth being exact about what that does and does not
# buy, because it is the one big cost this file CANNOT remove:
#
#   It stops nw's postinstall, which downloads a ~150MB NW.js runtime from
#   dl.nwjs.io -- and setup.sh triggers that three times over (the GUI, the App,
#   and the SDK build the test kit drives its window with). That download cannot
#   be pre-warmed from here. The installer caches it in the nw package's OWN
#   directory inside node_modules (its cacheDir defaults to "."), so there is no
#   shared location to put it; and pointing NWJS_CACHE_DIR somewhere shared moves
#   where it UNPACKS as well, out of node_modules, which is where both setup.sh
#   and the test kit go looking for the binary. So the runtime downloads stay in
#   setup.sh. Everything else -- resolution, metadata, and every package tarball,
#   nw's installer included -- is warmed here.
#
# --legacy-peer-deps because this is a union of five unrelated projects, two of
# them on webpack 4 and gulp 4 era peer ranges. The tree built here is deleted
# unread; only the cache survives, so a resolution npm dislikes is irrelevant as
# long as the tarballs land.
#
# The versions below mirror the checkouts' package.json files. If one drifts, npm
# fetches the newer one at setup time as it does now -- a stale entry is a wasted
# download here, never a wrong install there.

say 'pre-fetching the node dependencies into the npm cache'

mkdir -p "$OKC_WARM/npm"
cat >"$OKC_WARM/npm/package.json" <<'OKC_PKG_EOF'
{
  "name": "okc-cache-warm",
  "version": "0.0.0",
  "private": true,
  "dependencies": {
    "node-addon-api": "^8.9.1",
    "node-gyp": "^13.0.1",
    "node-hid": "^3.4.0",
    "@noble/ciphers": "^2.2.0",
    "@noble/curves": "^2.2.0",
    "@noble/hashes": "^2.2.0",
    "@noble/post-quantum": "^0.6.1",
    "nw": "^0.114.0-sdk",
    "nw-app": "npm:nw@^0.71.1",
    "nw-autoupdater": "^1.1.11",
    "nw-dev": "^3.0.1",
    "auto-launch": "^5.0.5",
    "js-sha256": "^0.9.0",
    "request": "^2.88.2",
    "sshpk": "^1.17.0",
    "chai": "^4.3.7",
    "chai-as-promised": "^7.1.1",
    "eslint": "^8.33.0",
    "fs-jetpack": "^5.1.0",
    "gulp": "^4.0.2",
    "gulp-sourcemaps": "^3.0.0",
    "json": "^11.0.0",
    "mocha": "^10.2.0",
    "q": "^1.5.1",
    "selenium-webdriver": "^4.8.0",
    "tree-kill": "^1.2.2",
    "yargs": "^17.6.2",
    "express": "^4.17.1",
    "gun": "^0.2020.520",
    "tapable": "^1.1.3",
    "xterm": "^4.8.1",
    "xterm-addon-fit": "^0.4.0",
    "@babel/core": "^7.29.7",
    "@babel/preset-env": "^7.29.7",
    "babel-loader": "^8.4.1",
    "babel-minify-webpack-plugin": "^0.3.1",
    "bootstrap": "^4.5.0",
    "cross-env": "^7.0.2",
    "csp-html-webpack-plugin": "^4.0.0",
    "file-saver": "^2.0.2",
    "html-webpack-plugin": "^4.3.0",
    "jquery": "^3.5.1",
    "jquery-ui": "^1.12.1",
    "jszip": "^3.4.0",
    "popper.js": "^1.16.1",
    "randomcolor": "^0.5.4",
    "raw-loader": "^4.0.1",
    "superagent": "^5.2.2",
    "webpack": "^4.43.0",
    "webpack-cli": "^3.3.11",
    "webpack-subresource-integrity": "^1.4.1"
  }
}
OKC_PKG_EOF

# A login shell, so this is nvm's npm and nvm's cache -- the same one the user
# gets when they run setup.sh, which is the whole point of warming it.
if bash -lc "cd '$OKC_WARM/npm' && npm install --ignore-scripts --legacy-peer-deps --no-audit --no-fund" >/dev/null 2>&1; then
  say 'node dependencies are cached — the five npm installs will resolve locally'
else
  # Same as above: whatever was fetched before the failure stays in the cache.
  say 'WARNING: the node pre-fetch did not finish — setup.sh will fetch the rest'
fi

# Only the cache was wanted. The tree itself is several hundred megabytes of
# something nothing will ever run.
rm -rf "$OKC_WARM"

# --- prove the machine is actually usable -------------------------------------
#
# Checked as the user, in a login shell, which is what a command sent to this machine
# gets. Each of these has been wrong before while looking right from a root shell, so
# they are reported rather than assumed.

say "node:   $(bash -lc 'node --version 2>/dev/null || echo MISSING')"
say "npm:    $(bash -lc 'npm --version 2>/dev/null || echo MISSING')"
say "pm2:    $(bash -lc 'pm2 --version 2>/dev/null || echo MISSING')"

# Docker without sudo depends on group membership, which is only read when a session
# starts -- so this is expected to say no until the machine has been rebooted once.
say "pip cache:  $(du -sh "$HOME/.cache/pip" 2>/dev/null | cut -f1 || echo MISSING)"
say "npm cache:  $(du -sh "$HOME/.npm" 2>/dev/null | cut -f1 || echo MISSING)"

# Built by extra.sh, and reported here rather than there because this is the shell
# a command sent to the machine actually gets -- and because until the next login
# this user cannot reach the daemon to ask.
if docker info >/dev/null 2>&1; then
  say 'docker: usable without sudo'
  if docker image inspect onlykey/onlykey-firmware-toolchain >/dev/null 2>&1; then
    say 'toolchain image: present — make docker-build-toolchain will be a cache hit'
  else
    say 'toolchain image: MISSING — setup.sh will build it, slowly'
  fi
else
  say 'docker: not usable without sudo yet — group membership applies from the next login'
  if sudo -n docker image inspect onlykey/onlykey-firmware-toolchain >/dev/null 2>&1; then
    say 'toolchain image: present (checked with sudo)'
  else
    say 'toolchain image: could not be checked from here yet'
  fi
fi

# The gadget's virtual UDC. The gadget itself is not up yet and is not expected to
# be: setup.sh builds it from the emulator's own HID descriptors, which arrive
# with the checkouts. What matters here is that the module it binds to is loaded,
# because THAT is the part that had to be compiled.
if lsmod 2>/dev/null | grep -q '^dummy_hcd'; then
  say "dummy_hcd: loaded, UDC $(ls /sys/class/udc 2>/dev/null | head -1 || echo '(none)')"
else
  say 'dummy_hcd: NOT loaded — setup.sh will build and load it (see extra.sh)'
fi
if id -nG 2>/dev/null | tr ' ' '\n' | grep -qx plugdev; then
  say 'plugdev: in the group'
else
  say 'plugdev: not in the group in THIS session — it applies from the next login'
fi

# The display only exists once somebody is logged in, which autologin arranges from
# the next boot.
if [ -n "${DISPLAY:-}" ] && xset q >/dev/null 2>&1; then
  say "display: $DISPLAY is reachable"
else
  say 'display: not reachable yet — autologin starts a session on the next boot'
fi

say 'extra (user) finished'
