#!/bin/bash
# This project's extra setup. It runs AFTER the app's toolchain, and adds to it.
#
# So there is nothing here about build tools, docker, a desktop session or node --
# the app's toolchain.sh already did those, and every machine gets them whether or
# not this file exists. Duplicating them here would mean two places to change and
# two chances to disagree.
#
# What IS here is only ours, and all of it genuinely needs root: a kernel module to
# build against, a particular device to flash, a udev rule for one vendor id, and a
# memory setting without which the emulator will not start. None of that belongs in a
# generic tool, which is why this file lives outside the app.
#
# Anything of ours that belongs to the user is in extra-user.sh, which runs as them.
#
# A header of OKC_* values and `say`/`report` helpers is prepended by the dashboard.

set -u

say 'extra (root): this project has more to add'

export DEBIAN_FRONTEND=noninteractive

# --- kernel build inputs -----------------------------------------------------
#
# For building a USB device controller out of tree. linux-headers is the part that
# matters; linux-source frequently has no package for a given kernel, which is
# normal rather than a failure.

say "installing kernel build inputs for $(uname -r)"
apt-get -o DPkg::Lock::Timeout=600 install -y --no-install-recommends "linux-headers-$(uname -r)" \
  || say "WARNING: no linux-headers for $(uname -r) — an out-of-tree module cannot be built"

if apt-get -o DPkg::Lock::Timeout=600 install -y --no-install-recommends "linux-source-$(uname -r | cut -d- -f1)" 2>/dev/null; then
  say 'linux-source is installed'
else
  say 'no linux-source package for this kernel, which is normal — fetch it from the archive if it is needed'
fi

if [ -d "/lib/modules/$(uname -r)/build" ]; then
  say "the kernel build tree is present for $(uname -r)"
else
  say "WARNING: no kernel build tree for $(uname -r), so a module build will fail"
fi

# During an install, the kernel running is the installer's and the one that will boot
# may be newer -- so headers can be right for the running kernel by luck rather than
# because they were asked for. Saying both makes a later mismatch obvious instead of
# something to discover while a build fails.
say "headers were installed for $(uname -r); after a reboot check that uname -r still matches"

# --- access to the flashing target -------------------------------------------
#
# Only the bootloader rule lives here. Rules for the device itself come from the
# project's own setup script, and two sources of truth for the same device
# permissions is how they drift apart.

# The rule below names plugdev, and so does the emulator's own. A rule naming a
# group that does not exist is an error udev reports only in its own log, so it
# is created here rather than assumed: Debian's installer makes it, a minimal
# cloud image usually does not.
if getent group plugdev >/dev/null 2>&1; then
  say 'the plugdev group exists'
elif groupadd plugdev 2>/dev/null; then
  say 'created the plugdev group'
else
  say 'WARNING: could not create plugdev — the udev rules below will not apply'
fi

# Group membership is only read when a session starts. Adding the user HERE, before
# they have ever logged in, is the difference between the device working on their
# first login and the project telling them to log out and back in again -- which is
# what the emulator's own setup prints today, because by then it is too late.
OKC_TARGET_USER="${OKC_USER:-${SUDO_USER:-}}"
if [ -z "$OKC_TARGET_USER" ]; then
  # The first ordinary login account: uid in the human range, with a real shell.
  OKC_TARGET_USER="$(awk -F: '$3>=1000 && $3<65534 && $7 !~ /(nologin|false)$/ {print $1; exit}' /etc/passwd)"
fi
if [ -n "$OKC_TARGET_USER" ] && id "$OKC_TARGET_USER" >/dev/null 2>&1; then
  if usermod -aG plugdev "$OKC_TARGET_USER" 2>/dev/null; then
    say "added $OKC_TARGET_USER to plugdev"
  else
    say "WARNING: could not add $OKC_TARGET_USER to plugdev"
  fi
else
  say 'WARNING: found no ordinary user to put in plugdev'
fi

say 'granting access to the flashing target'
cat >/etc/udev/rules.d/49-okc-bootloader.rules <<'RULES'
# The bootloader this project flashes through (16c0:0478).
# Rules for the device itself are installed by the project's own setup script,
# deliberately not from here.
SUBSYSTEM=="usb", ATTRS{idVendor}=="16c0", ATTRS{idProduct}=="0478", MODE="0660", GROUP="plugdev", TAG+="uaccess"
KERNEL=="hidraw*", ATTRS{idVendor}=="16c0", ATTRS{idProduct}=="0478", MODE="0660", GROUP="plugdev", TAG+="uaccess"
RULES
udevadm control --reload-rules 2>/dev/null || true
udevadm trigger 2>/dev/null || true

# --- allow a low address to be mapped ----------------------------------------
#
# Without this the emulator segfaults on start, and the crash does not say why.
# Written as a sysctl file so it survives a reboot.

say 'allowing low memory mapping'
echo 'vm.mmap_min_addr = 4096' >/etc/sysctl.d/60-okc-mmap.conf
sysctl -p /etc/sysctl.d/60-okc-mmap.conf >/dev/null 2>&1 \
  || say 'could not apply vm.mmap_min_addr now; it applies on the next boot'

# --- the gadget's kernel module ----------------------------------------------
#
# This section used to say the USB gadget was deliberately not here, and while it
# was only a modprobe that was right. It is not only a modprobe. dummy_hcd is a
# virtual USB Device Controller and Ubuntu ships `# CONFIG_USB_DUMMY_HCD is not
# set`, so no package provides it: it has to be COMPILED against the running
# kernel, from a source file the machine does not have. On an HWE kernel there is
# no linux-source package to get that file from either, so the project falls back
# to pulling it out of the archive pool -- a ~200MB tarball, for one .c file.
#
# That is minutes of every setup.sh run, it is byte-for-byte identical on every
# machine built from this point, and it needs root. Which is the description of
# something that belongs in provisioning.
#
# It matters at all because UHID is not a good enough stand-in for hardware: a
# UHID device has no USB parent, so hidapi reports an empty manufacturer and
# interface -1, and real software identifies an OnlyKey by exactly those fields.
# dummy_hcd is what lets the emulated device enumerate with genuine descriptors.
#
# TWO things are left behind, and the second matters as much as the first:
#
#   1. the module, built, installed into /lib/modules/<rel>/updates and loaded, so
#      a UDC exists for a gadget to bind to; and
#
#   2. the SOURCE, stashed at /usr/src/linux-source-<upstream>-okc/, which is a
#      path the project's own build-dummy-hcd.sh already searches before it goes
#      near the network. setup.sh WILL rebuild the module -- it looks for the .ko
#      inside the checkout, not here, and that is its business rather than
#      something to work around -- but with the source already on disk that
#      rebuild is one small file compiled offline in seconds, instead of the
#      download.
#
# The gadget ITSELF is not created here, and cannot be: configfs needs the HID
# descriptors read out of the emulator's own source tree, which is not on the
# machine yet. That step is cheap. This one was not.
#
# If the machine boots a NEWER kernel than the installer ran (see the note above),
# the module built here does not load and the stashed source is for the wrong
# version. Nothing breaks: build-dummy-hcd.sh finds no match for the new kernel's
# glob and falls back to its own ladder, exactly as on an unprovisioned machine.

say 'building the usb gadget kernel module'

OKC_KREL="$(uname -r)"
OKC_UPSTREAM="${OKC_KREL%%-*}"                       # 6.8.0-138-generic -> 6.8.0
OKC_HCD_REL='drivers/usb/gadget/udc/dummy_hcd.c'
OKC_HCD_STASH="/usr/src/linux-source-${OKC_UPSTREAM}-okc"
OKC_HCD_SRC="$OKC_HCD_STASH/$OKC_HCD_REL"

okc_hcd_have() { [ -s "$OKC_HCD_SRC" ]; }

okc_fetch() {
  if command -v curl >/dev/null 2>&1; then curl -fsSL "$1"
  elif command -v wget >/dev/null 2>&1; then wget -qO- "$1"
  else return 1; fi
}
okc_exists() {
  if command -v curl >/dev/null 2>&1; then curl -fsI --max-time 20 "$1" >/dev/null 2>&1
  elif command -v wget >/dev/null 2>&1; then wget -q --spider --timeout=20 "$1" 2>/dev/null
  else return 1; fi
}

mkdir -p "$(dirname "$OKC_HCD_SRC")"

# The same ladder the project uses, in the same order: cheapest and most certainly
# correct first. Each rung derives what it needs from `uname -r`, so none of this
# pins a kernel version.

# A self-built or mainline kernel points /lib/modules/<rel>/build at the tree it was
# compiled from. When that hits it is the one copy guaranteed to match this kernel.
if [ -f "/lib/modules/$OKC_KREL/build/$OKC_HCD_REL" ]; then
  cp "/lib/modules/$OKC_KREL/build/$OKC_HCD_REL" "$OKC_HCD_SRC" 2>/dev/null || true
  okc_hcd_have && say 'took dummy_hcd.c from the kernel build tree'
fi

# An already-unpacked tree, from linux-source having been extracted by hand.
if ! okc_hcd_have; then
  for okc_d in /usr/src/linux-source-"$OKC_UPSTREAM"*/ /usr/src/linux-"$OKC_UPSTREAM"*/; do
    [ "$okc_d" = "$OKC_HCD_STASH/" ] && continue
    [ -f "$okc_d$OKC_HCD_REL" ] || continue
    cp "$okc_d$OKC_HCD_REL" "$OKC_HCD_SRC" 2>/dev/null || true
    okc_hcd_have && { say "took dummy_hcd.c from $okc_d"; break; }
  done
fi

# The linux-source tarball, where the distribution publishes one -- which the
# section above tried to install. GNU tar detects the compression itself, and
# --occurrence=1 stops it at the first match rather than reading the remaining
# ~1.5GB of the tree.
if ! okc_hcd_have; then
  for okc_t in /usr/src/linux-source-"$OKC_UPSTREAM".tar.* \
               /usr/src/linux-source-"${OKC_UPSTREAM%.*}".tar.*; do
    [ -f "$okc_t" ] || continue
    tar -xO --wildcards --occurrence=1 -f "$okc_t" "*/$OKC_HCD_REL" >"$OKC_HCD_SRC" 2>/dev/null || true
    okc_hcd_have && { say "extracted dummy_hcd.c from $okc_t"; break; }
  done
fi

# Last resort: the source tarball in the archive pool. An HWE kernel is built from
# a differently-named source package that ships no linux-source binary at all, so
# the rung above can never hit there -- ask dpkg which source package built the
# headers that ARE installed, and fetch that. tar exits at the first match, which
# SIGPIPEs the download, so only as much of the tarball as it takes to reach
# drivers/ is ever transferred. Every mirror apt is actually configured for is
# tried, since a kernel can live outside main and the host may be on a local
# mirror; archive.ubuntu.com is the floor, not the assumption.
if ! okc_hcd_have && command -v dpkg-query >/dev/null 2>&1; then
  OKC_SRCPKG="$(dpkg-query -W -f='${source:Package}' "linux-headers-$OKC_KREL" 2>/dev/null || true)"
  if [ -n "${OKC_SRCPKG:-}" ]; then
    case $OKC_SRCPKG in
      lib?*) OKC_SHARD="${OKC_SRCPKG:0:4}" ;;
      *)     OKC_SHARD="${OKC_SRCPKG:0:1}" ;;
    esac
    OKC_BASES="$(apt-get indextargets --format '$(REPO_URI) $(COMPONENT)' 2>/dev/null \
                 | sort -u | awk 'NF==2 {sub(/\/$/,"",$1); print $1 "/pool/" $2}')
http://archive.ubuntu.com/ubuntu/pool/main"
    while read -r okc_base; do
      [ -n "$okc_base" ] || continue
      okc_hcd_have && break
      for okc_ext in gz xz bz2; do
        # The orig tarball carries the upstream version only: 6.8.0-138.xx is
        # packaged as <src>_6.8.0.orig.tar.*.
        okc_url="$okc_base/$OKC_SHARD/$OKC_SRCPKG/${OKC_SRCPKG}_${OKC_UPSTREAM}.orig.tar.$okc_ext"
        # HEAD first: a 404 body piped into tar looks like an empty match, and
        # there are a dozen candidates to get through.
        okc_exists "$okc_url" || continue
        case $okc_ext in gz) okc_z=-z ;; xz) okc_z=-J ;; bz2) okc_z=-j ;; esac
        say "fetching dummy_hcd.c from $okc_url"
        # tar auto-detects compression only when it can seek, so reading a pipe the
        # decompressor has to be named explicitly.
        okc_fetch "$okc_url" | tar -xO "$okc_z" --wildcards --occurrence=1 "*/$OKC_HCD_REL" \
          >"$OKC_HCD_SRC" 2>/dev/null || true
        okc_hcd_have && break
      done
    done <<OKC_BASES_EOF
$OKC_BASES
OKC_BASES_EOF
  fi
fi

if okc_hcd_have; then
  say "dummy_hcd.c is stashed at $OKC_HCD_SRC — the project's rebuild will find it there"
else
  rm -f "$OKC_HCD_SRC"
  say "WARNING: could not obtain dummy_hcd.c for $OKC_KREL — setup.sh will try its own ladder"
fi

if okc_hcd_have && [ -d "/lib/modules/$OKC_KREL/build" ]; then
  OKC_HCD_BUILD=/var/lib/okc/dummy_hcd
  mkdir -p "$OKC_HCD_BUILD"
  cp "$OKC_HCD_SRC" "$OKC_HCD_BUILD/dummy_hcd.c"
  printf 'obj-m += dummy_hcd.o\n' >"$OKC_HCD_BUILD/Makefile"
  if make -C "/lib/modules/$OKC_KREL/build" M="$OKC_HCD_BUILD" modules >/dev/null 2>&1; then
    install -D -m 0644 "$OKC_HCD_BUILD/dummy_hcd.ko" "/lib/modules/$OKC_KREL/updates/dummy_hcd.ko"
    depmod -a
    say "dummy_hcd.ko built and installed for $OKC_KREL"

    # libcomposite and usb_f_hid are in the stock kernel; only dummy_hcd was missing.
    modprobe libcomposite 2>/dev/null || say 'WARNING: libcomposite did not load'
    modprobe usb_f_hid 2>/dev/null || true
    modprobe dummy_hcd 2>/dev/null \
      || insmod "/lib/modules/$OKC_KREL/updates/dummy_hcd.ko" 2>/dev/null \
      || say 'WARNING: dummy_hcd did not load'

    # uhid is the fallback transport and is a module on stock Ubuntu. One line, and
    # it saves the project a modprobe-and-persist step of its own.
    modprobe uhid 2>/dev/null || true
    printf 'uhid\n' >/etc/modules-load.d/onlykey-emulator.conf
    printf 'libcomposite\ndummy_hcd\n' >/etc/modules-load.d/onlykey-gadget.conf

    # configfs is where the gadget gets built, and it is not mounted by default on
    # every image. It is volatile either way -- the gadget itself has to be rebuilt
    # at each boot, which is the project's systemd unit's job, not this file's.
    if command -v mountpoint >/dev/null 2>&1 && ! mountpoint -q /sys/kernel/config; then
      mount -t configfs none /sys/kernel/config 2>/dev/null || true
    fi

    OKC_UDC="$(ls /sys/class/udc 2>/dev/null | head -1 || true)"
    if [ -n "${OKC_UDC:-}" ]; then
      say "a virtual UDC is present: $OKC_UDC — the gadget has something to bind to"
    else
      say 'WARNING: no UDC under /sys/class/udc — the emulator will fall back to UHID'
    fi
  else
    say "WARNING: dummy_hcd did not compile against $OKC_KREL — setup.sh will try again"
  fi
elif okc_hcd_have; then
  say "WARNING: no kernel build tree for $OKC_KREL — dummy_hcd cannot be compiled here"
fi

# --- what the app needs in order to START ------------------------------------
#
# `npm start` in OnlyKey-App builds fine and then dies on the launch:
#
#   nw: error while loading shared libraries: libasound.so.2:
#       cannot open shared object file: No such file or directory
#
# NW.js LINKS ALSA WHETHER OR NOT THERE IS ANY SOUND. This is a server image with
# a desktop added on top, and nothing else on it pulls that library in -- so the
# build reports success, every gulp task finishes, and the window never appears.
# The failure is at the very end, after everything that looks like the hard part
# has already worked, which is what makes it worth a line here.
#
# `libasound2t64` IS THE NOBLE NAME. Ubuntu renamed it in the 64-bit time_t
# transition; on anything older it is `libasound2`, so both are tried rather than
# pinning this file to one release of one distribution.
#
# IF MORE OF THESE TURN UP, THEY GO HERE. A missing shared library is exactly the
# shape of thing provisioning is for: identical on every machine, seconds at
# build time, and an afternoon to find by hand.

say 'installing what the app needs to start'
if apt-get -o DPkg::Lock::Timeout=600 install -y --no-install-recommends libasound2t64 2>/dev/null; then
  say 'libasound2t64 is installed'
elif apt-get -o DPkg::Lock::Timeout=600 install -y --no-install-recommends libasound2 2>/dev/null; then
  say 'libasound2 is installed (this release has not renamed it)'
else
  say 'WARNING: no libasound could be installed -- nw will not start, and the build will not say so'
fi

# --- what the app needs in order to be READABLE ------------------------------
#
# The OnlyKey App draws its whole left-hand nav with LITERAL EMOJI and bundles no
# icon font of its own. With no emoji font on the machine, every icon above
# U+FFFF renders as a hollow box -- and nothing reports it. There is no missing
# file, no failed task and no error line; the build succeeds and the window opens.
#
# WHAT MAKES IT READ AS A BROKEN BUILD rather than a missing system font is that
# it is PARTIAL. The two low-codepoint symbols the DejaVu fallback happens to
# carry, the Slots gear (U+2699) and the theme sun (U+2600), keep rendering. So
# the nav comes up half icons and half boxes, which looks like the app drawing
# itself wrong rather than like a font that was never installed.
#
# Same shape as libasound above, and here for the same reason: identical on every
# machine, seconds at build time, and an afternoon to find by hand.

say 'installing what the app needs to render'
if apt-get -o DPkg::Lock::Timeout=600 install -y --no-install-recommends fonts-noto-color-emoji 2>/dev/null; then
  say 'fonts-noto-color-emoji is installed'
else
  say 'WARNING: no emoji font could be installed -- the app nav will render as boxes, and nothing will say so'
fi

# --- headers the native node addons build against ----------------------------
#
# node-hid ships prebuilt binaries, which is exactly why this is worth installing
# ahead of time: while a prebuilt matches, nothing here is needed and nothing here
# is noticed. When one does not -- a Node major it has not shipped for yet -- npm
# quietly falls back to compiling from source and dies on a missing udev header,
# partway through installing something that looks nothing to do with USB.
#
# The -dev packages, not the runtimes. The runtimes are on any machine that has a
# desktop; it is the headers that are absent. Compilers and node itself come from
# the app's toolchain and are deliberately not repeated here.

say 'installing headers for the native node addons'
apt-get -o DPkg::Lock::Timeout=600 install -y --no-install-recommends libudev-dev libusb-1.0-0-dev \
  || say 'WARNING: no libudev/libusb headers -- a node-hid build from source will fail'

# --- what the PYTHON side needs in order to build -----------------------------
#
# okpqc-venv is created by setup.sh from the checkouts, so the venv itself cannot
# be made here -- where it goes depends on where the repos are cloned. Its
# CONTENTS can be got ready though, and that is done in extra-user.sh, which fills
# the user's pip cache so the real venv is a copy rather than a compile.
#
# These are the pieces that compile needs, and they are root's to install:
#
#   python3-venv  Debian splits ensurepip out of the stdlib, and without it
#                 `python3 -m venv` fails with a message telling you to install
#                 this -- at the very first thing setup.sh does with Python.
#   python3-dev   hidapi, pynacl, pycryptodome and Cython all build C extensions.
#   pkg-config    how hidapi's build locates libudev and libusb.
#
# The libudev/libusb headers those builds need are installed above for node-hid.
# They are the same two packages, which is why they are not repeated here.

say 'installing what the python side needs to build'
apt-get -o DPkg::Lock::Timeout=600 install -y --no-install-recommends python3-venv python3-dev pkg-config \
  || say 'WARNING: no python3-venv/python3-dev — okpqc-venv will fail or build nothing'

# --- the firmware toolchain image ---------------------------------------------
#
# setup.sh builds `onlykey/onlykey-firmware-toolchain` through the arduino
# checkout's `make docker-build-toolchain`. That Dockerfile is ubuntu:focal plus a
# single apt-get of a dozen packages -- `arduino` and its Java bits among them --
# so it is several hundred megabytes and minutes of a run, and it is the same
# image on every machine.
#
# It can be built HERE, with none of the checkouts on the machine, because that
# Dockerfile has NO COPY AND NO ADD. Nothing in it reads the build context, so the
# 876MB of Arduino/Teensyduino sitting beside it is not an input to any layer, and
# an empty directory is as good a context as the repo. The recipe is reproduced
# below and built under the same tag; when the real `docker build` runs later it
# matches layer for layer and returns immediately.
#
# REPRODUCED IS THE WORD. Docker keys a RUN layer on its parent image plus the
# literal command text, so this has to be byte-identical -- down to the TAB that
# begins the second line and the two spaces after `apt-get update`. It is written
# with printf rather than a heredoc for exactly that reason: this file gets pasted
# between editors on its way to a machine, and a tab silently becoming spaces
# would turn the cache hit back into a full rebuild with nothing to show why.
#
# If the project's Dockerfile ever changes, the keys stop matching and setup.sh
# builds the image itself, exactly as it does on an unprovisioned machine. The
# failure mode of this section going stale is lost time, never a broken build.
#
# amd64 whatever the host is, matching what setup.sh does: the legacy
# Arduino/Teensyduino bundle ships pre-compiled x86_64 binaries, so a native arm64
# image builds perfectly and then cannot execute a single one of them.

say 'pre-building the firmware toolchain image'
if ! command -v docker >/dev/null 2>&1; then
  say 'WARNING: no docker — setup.sh will skip the firmware toolchain image entirely'
elif ! docker info >/dev/null 2>&1; then
  say 'WARNING: docker is not running — the toolchain image is not pre-built'
else
  if [ "$(uname -m)" != "x86_64" ]; then
    # Without a binfmt handler an amd64 build on arm64 cannot run the image's own
    # apt. Correct but slow through qemu, which is the trade this project already
    # makes; setup.sh skips the image outright when the handler is absent.
    apt-get -o DPkg::Lock::Timeout=600 install -y --no-install-recommends qemu-user-static binfmt-support \
      || say 'WARNING: no qemu-user-static — an amd64 image cannot be built on this host'
  fi

  OKC_CTX="$(mktemp -d)"
  {
    printf 'FROM ubuntu:focal\n'
    printf 'MAINTAINER admin <hello@admin.com>\n'
    printf '\n\n'
    printf '# Install necessary packages\n'
    printf 'RUN ln -fs /usr/share/zoneinfo/America/New_York /etc/localtime \\\n'
    printf '\t&& apt-get update  \\\n'
    printf '  && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \\\n'
    for okc_pkg in ca-certificates make wget bzip2 git curl build-essential xvfb arduino \
                   libgtk2.0 libjssc-java libjss-java; do
      printf '    %s \\\n' "$okc_pkg"
    done
    printf '  && rm -rf /var/lib/apt/lists/*\n'
    printf '  \n  \n'
  } >"$OKC_CTX/Dockerfile"

  if DOCKER_DEFAULT_PLATFORM=linux/amd64 docker build -t onlykey/onlykey-firmware-toolchain "$OKC_CTX" >/dev/null; then
    say 'the firmware toolchain image is built — make docker-build-toolchain will hit the cache'
  else
    say 'WARNING: could not pre-build the toolchain image — setup.sh will build it the slow way'
  fi
  rm -rf "$OKC_CTX"
fi

say 'extra (root) finished'
